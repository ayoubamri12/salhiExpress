<?php echo e(QrCode::size(300)
            ->generate($parcel->qr_code)); ?><?php /**PATH C:\laragon\www\salhi_project\salhiExpress\resources\views/parcels/show.blade.php ENDPATH**/ ?>