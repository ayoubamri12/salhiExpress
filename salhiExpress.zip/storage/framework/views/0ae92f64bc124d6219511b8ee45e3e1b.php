<style>
    .modal-body {
        background-color: #fff;
        border-color: #fff;
    }

    .close {
        color: #000;
        cursor: pointer;
    }

    .close:hover {
        color: #000;
    }

    .theme-color {
        color: rgb(175, 122, 23);
    }

    hr.new1 {
        border-top: 2px dashed #fff;
        margin: 0.4rem 0;
    }
</style>

<?php if (isset($component)) { $__componentOriginal2f636fea8b08a2532dbc4cc7059fb6ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f636fea8b08a2532dbc4cc7059fb6ce = $attributes; } ?>
<?php $component = App\View\Components\DeliverLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('deliver-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DeliverLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="loaderHolder" style="display: none" class="loading">
        <p class="loader"></p>
    </div>
    <?php if(session()->has('success')): ?>
        <script>
            document.querySelector("div#loaderHolder").style.display = "none"
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": true,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            };
            toastr.success("bien");
        </script>
    <?php endif; ?>
    <div id="parent" class="mt-5 mx-auto" style="width:100%;padding:15px;">
        <div class="my-2">
            <p  style="color: rgb(165, 165, 165)">Nombre de colis : <?php echo e($colis->count()); ?> </p>
        </div>
        <?php if($colis->count() > 0): ?>
            <?php $__currentLoopData = $colis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$coli->complaint): ?>
                    <div>
                        <p style="color: rgb(165, 165, 165)">Reporté a : <?php echo e($coli->delay); ?> :</p>
                    </div>

                    <div class="card my-2">
                        <div class="card-header border-0 p-0 bg-light d-flex justify-content-end">

                            <button type="button" class="btn btn-light border-0" data-bs-toggle="modal"
                                data-bs-target="#staticBackdrop<?php echo e($coli->id); ?>">
                                <i class="icon ph-bold ph-info"
                                    style="color: orange; font-size: 35px; cursor: pointer;"></i>
                            </button>
                            <div class="modal fade" id="staticBackdrop<?php echo e($coli->id); ?>" data-bs-backdrop="static"
                                data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel"
                                aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="border-0 btn bg-light btn-close"
                                                data-bs-dismiss="modal" aria-label="Close" style="cursor: pointer;">
                                                <i style="font-size: 30px;" class="icon ph-bold ph-x text-danger"></i>
                                            </button>
                                        </div>
                                        <div class="modal-body">

                                            <div class="px-4 py-5">
                                                <h5 class="text-uppercase">Client : <?php echo e($coli->Name); ?></h5>
                                                <span class="theme-color d-inline-block w-75 mx-auto">Coli
                                                    code : <?php echo e($coli->code); ?></span>
                                                <div class="mb-3">
                                                    <hr class="new1">
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <span class="font-weight-bold">Ville :
                                                        <?php echo e($coli->destination); ?></span>
                                                    <span class="text-muted">Prix : <?php echo e($coli->price); ?>

                                                        DH</span>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <small>Telephone : <a
                                                            href="tel:<?php echo e($coli->phone_number); ?>"><?php echo e($coli->phone_number); ?></a></small>
                                                    <small><i class="fab fa-whatsapp"></i> WhatsApp :<a
                                                            href="https://wa.me/<?php echo e($coli->phone_number); ?>?text=Hello%20there!"
                                                            target="_blank"><?php echo e($coli->phone_number); ?></a></small>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <small>La date :</small>
                                                    <small><?php echo e($coli->created_at); ?></small>
                                                </div>
                                                <div class="d-flex justify-content-between mt-3">
                                                    <span class="font-weight-bold">Magasin :</span>
                                                    <span
                                                        class="font-weight-bold theme-color"><?php echo e($coli->magasin); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                        <div class="card-body bg-light">
                            <div class="row justify-content-start align-items-center mb-3">
                                <div class="col-6 text-start">
                                    <p style="font-size: 11px;color:gray;">Client :<?php echo e($coli->Name); ?> <br> Code colis
                                        :<?php echo e($coli->code); ?></p>
                                </div>
                            </div>
                            <div class="row mx-auto justify-content-around">
                                <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6a555649da86b3de44465cdfe004aa4 = $attributes; } ?>
<?php $component = App\View\Components\Modal::resolve(['coli' => $coli->id] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                    <form action="<?php echo e(route('colis.status', ['id' => $coli->id])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="">
                                            <div class="row justify-content-center">
                                                <div class="col-3">
                                                    <img src="<?php echo e(asset('/assets/images/profile.png')); ?>" alt=""
                                                        width="70" height="70">
                                                </div>
                                            </div>
                                            <h5 class="pt-1 my-3">
                                                <?php echo e(auth()->user()->deliverymen->firtsName . ' ' . auth()->user()->deliverymen->lastName); ?>

                                            </h5>

                                            <div data-mdb-input-init class="form-outline mb-4">
                                                <select class="form-control" name="status" data-size="4">
                                                    <option value="">Select Status</option>
                                                    <option value="livré">Livré</option>
                                                    <option value="Reporté">Reporté</option>
                                                    <option value="Annulé">Annulé</option>
                                                    <option value="Refusé">Refusé</option>
                                                </select>
                                                <label class="form-label" for="name4">Status</label>
                                            </div>
                                            <div class="cmt" style="display: none; margin-bottom:20px">
                                                <textarea id="comment" name="comment" rows="4" class="form-control"></textarea>
                                                <label class="form-label" for="comment">Commentaire</label>
                                            </div>


                                            <!-- Submit button -->
                                            <button data-bs-dismiss="modal" aria-label="Close" type="submit"
                                                id="sub" class="btn text-light"
                                                style="background-color: orange; cursor: pointer;">Valider</button>
                                        </div>
                                    </form>

                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $attributes = $__attributesOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__attributesOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p class="alert alert-warning">no delayed parcels for today</p>
        <?php endif; ?>
        <p id="alrt" style="display: none;" class="alert alert-warning">no delayed parcels for today</p>
    </div>

    <script>
        if ($("#parent").children().length === 1) {
            $("p#alrt").css("display", "block")
            console.log($("#parent").children().length);
        }

        $("select[name=status]").on("change", function() {
            if ($(this).val() === "Reporté" || $(this).val() === "Annulé" || $(this).val() ===
                "Refusé") {
                $(this).parent().next("div.cmt").css("display", "block");
                console.log($(this).parent().next("div.cmt"));
            } else {
                $(this).parent().next("div.cmt").css("display", "none");
                 console.log($(this).parent().next("div.cmt"));
            }
        });

        $("#sub").click(function() {
            document.querySelector("div#loaderHolder").style.display = "flex";
        })
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f636fea8b08a2532dbc4cc7059fb6ce)): ?>
<?php $attributes = $__attributesOriginal2f636fea8b08a2532dbc4cc7059fb6ce; ?>
<?php unset($__attributesOriginal2f636fea8b08a2532dbc4cc7059fb6ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f636fea8b08a2532dbc4cc7059fb6ce)): ?>
<?php $component = $__componentOriginal2f636fea8b08a2532dbc4cc7059fb6ce; ?>
<?php unset($__componentOriginal2f636fea8b08a2532dbc4cc7059fb6ce); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\salhi_project\salhiExpress\resources\views/delivers/delayed_parcels.blade.php ENDPATH**/ ?>