<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/login.css')); ?>">
    <style>
        .h-custom {
            height: 100vh;
        }
        
    </style>
</head>
<body>
    
    <section class="vh-100">
        <div class="container-fluid h-custom">
            <?php if(session()->has('success')): ?>
            <div id="alert" class="my-3 alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session("success")); ?>

                <button type="button" id="cls" class="close button" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-md-9 col-lg-6 col-xl-5 col-12 text-center">
                    <img src="<?php echo e(asset('/assets/images/aloo-salhi-logo-new.png')); ?>" class="img-fluid" alt="Image d'exemple">
                </div>
                <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1 col-12">
                    <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <form id="form" action="<?php echo e(url("/login/store")); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-outline mb-4">
                            <label class="form-label" style="font-size: 18px; color: orange; font-weight: bolder" for="form3Example3">Adresse de connexion :</label>
                            <input type="text" id="form3Example3" class="form-control form-control-lg" placeholder="Entrez une adresse de connexion valide" value="<?php echo e(old('login')); ?>" name="login" />
                        </div>
                        <label class="form-label" style="font-size: 18px; color: orange; font-weight: bolder" for="form3Example4">Mot de passe :</label>
                        <div class="form-outline mb-3">
                            <input type="password" id="form3Example4" class="form-control form-control-lg" placeholder="Entrez le mot de passe" name="password"/>
                        </div>
                        <div class="text-center text-lg-start mt-4 pt-2 pb-4">
                            <button type="submit" id="sub" class="btn btn-lg button" style="padding-left: 2.5rem; padding-right: 2.5rem; background-color: orange;">Connexion</button>
                            <p class="small fw-bold mt-2 pt-1 mb-0" style="font-size: 20px">Vous n'avez pas de compte ? <a href="<?php echo e(route('login.registerShown')); ?>" class="link-danger">Créer un nouveau compte</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
       
    <?php if($errors->any()): ?>
<script>
    document.getElementById("sub").disabled=false

</script>
    <?php endif; ?>
    <script>
        const close = ()=>{
            document.getElementById("alert").style.display="none"
        }
        document.getElementById("cls") ? document.getElementById("cls").onclick = close : "";
        document.getElementById("sub").onclick = (e)=>{
            document.getElementById("form").submit();
            e.target.disabled=true
        };

    </script>
</body>
</html><?php /**PATH C:\laragon\www\salhi_project\salhiExpress\resources\views/login/login.blade.php ENDPATH**/ ?>