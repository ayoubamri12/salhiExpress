<style>
    @media (max-width: 600px) {
        h1 {
            font-size: 1.5em;
        }

       .ctr{
        width: 75%;
       }

        #qr-code-result {
            font-size: 1em;
        }
    }
</style>
<?php if (isset($component)) { $__componentOriginal2f636fea8b08a2532dbc4cc7059fb6ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f636fea8b08a2532dbc4cc7059fb6ce = $attributes; } ?>
<?php $component = App\View\Components\DeliverLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('deliver-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DeliverLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="ctr">
        <div class="card mt-5">
            <div class="card-header" style="background-color: orange;">
                <h1>Scan QR Code <i class="fa fa-qrcode"></i></h1>
            </div>
            <div class="card-body">
                <div id="qr-code-result"></div>
                <div style="display: flex;justify-content: center;">
                    <div id="qr-code-reader" style="width: 500px;"></div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f636fea8b08a2532dbc4cc7059fb6ce)): ?>
<?php $attributes = $__attributesOriginal2f636fea8b08a2532dbc4cc7059fb6ce; ?>
<?php unset($__attributesOriginal2f636fea8b08a2532dbc4cc7059fb6ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f636fea8b08a2532dbc4cc7059fb6ce)): ?>
<?php $component = $__componentOriginal2f636fea8b08a2532dbc4cc7059fb6ce; ?>
<?php unset($__componentOriginal2f636fea8b08a2532dbc4cc7059fb6ce); ?>
<?php endif; ?>
<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
<script>
    const ready = document.getElementById('qr-code-reader');
    const result = document.getElementById('qr-code-result');

    function demoReady(fn) {
        if (document.readyState === "complete" || document.readyState === "interactive") {
            setTimeout(fn, 1);
        } else
            document.addEventListener("DOMContentLoaded", fn)

    }

    demoReady(function() {
        let lastResult, counter = 0;

        function onScanSuccess(decodeText, decodeResult) {
            if (decodeText !== lastResult) {
                ++counter;
                lastResult = decodeText
                console.log("qr code" + decodeText, decodeResult);
                result.innerHTML = 'you scan ' + counter + " " + decodeText
            }
        }
        let htmlscanner = new Html5QrcodeScanner("qr-code-reader", {
            fps: 20,
            qrbox: 300
        })
        htmlscanner.render(onScanSuccess);
    })
    /* const html5QrCode = new Html5Qrcode("qr-code-reader");
             const fileinput = document.getElementById('qr-input-file'); fileinput.addEventListener('change', e => {
                 if (e.target.files.length == 0) {
                     return;
                 }

                 const imageFile = e.target.files[0];
                 html5QrCode.scanFile(imageFile, true)
                     .then(decodedText => {
                         console.log(decodedText);
                     })
                     
             });*/
</script>
<?php /**PATH C:\laragon\www\salhi_project\salhiExpress\resources\views/delivers/scan_parcel.blade.php ENDPATH**/ ?>